/*
FuckDevTools.Js
By @ghalbeyou on GitHub
https://github.com/GhalbeYou
Forked by: https://teskedsgumman.se
---------------------------------------
This is a simple script that will disable the developer tools in the browser.
*/

// The CONFIG:
var disable_right_click = /* If this was true, the user cannot right click and if they do, they see alert DevTools? */ true;
var disable_f12 = /* If this was true, users cannot do f12 */ true;
var disable_csi = /* if this was true, users cannot do control shift i */ true;
var disable_CtrlJ = /* If this was true, users cannot do CtrJ */ true;
var disable_CtrlC = /* If this was true, users cannot do f12 */ true;
var disable_CtrlA = /* If this was true, users cannot do Ctrl+A */ true; 
var disable_CtrlC = /* If this was true, users cannot do Ctrl+C */ true;
var disable_CtrlV = /* If this was true, users cannot do Ctrl+V */ true;
document.onkeydown = function(event) {
    if (disable_f12 == true){
        if (event.keyCode == 123) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
    // if the user pressed the Control + Shift + I key
    if (disable_csi == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
}
    // if the user pressed the Control + Ctrl Shift + J
    if (disable_CtrlJ == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
}
    // if the user pressed the Control + Ctrl + Shift + C
    if (disable_CtrlC == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
}
    // if the user pressed the Control + Ctrl+A
    if (disable_CtrlA == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
}
    // if the user pressed the Control + Ctrl+C
    if (disable_CtrlC == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
}
    // if the user pressed the Control + Ctrl+V
    if (disable_CtrlV == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
            location.replace("about:blank");
        }
    }
}
if (disable_right_click == true){   
    document.oncontextmenu = function() {
        event.preventDefault();
        alert("Devtools?");
    }
}
